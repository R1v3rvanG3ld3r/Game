
 var l = prompt("This game is 18+ and up.Are you 18+?")
 
 var game = prompt("Would you like to particidpate in the campfire camp game?")
var a = prompt("How many people are you with?")
var b = prompt("Do you want a marshmello or a lolly pop?")
var c = alert("Jan joined the campfire camp.")
var d = prompt("Do you want to give Jan a marshmello or a lolly pop?")

if(d == "marshmello"){
    var e = alert("Jan doesn't like marshmellos.HE'S MAD!")
    var g = alert("YOU DIED,you survived 1 round.")
}else{ 
          d == ("lolly pop")
          var h = alert("Jan LOVES lolly pops.")
}       
var e = prompt("Kees joined the campfire camp.he says hello.")
var f = prompt("Do you want to give Kees 1 or more marshmellos?")
if(f == "1"){
  }else{ 
    f == ("more")
    var v = prompt ("Kees is midly upset because he is on a diet right now.are you gonna say sorry to him?")
    if(v == "sorry"){
    var x = prompt("Kees says thank you.what are you gonna say to him?")
        if(x == "no problem"){
            var aa = alert("Its alright.")
        }
    }
  }
  var l = prompt("Suddenly a bear comes up,he seems to not bother")
  var k = prompt("what is your defence gonna be? The hot marshmellows or ")
    var end = alert("THE END!")

  